public class Queue {
    public static class Node{
        String data;
        Node next;

        public Node() {
            this.data = null;
            this.next = null;
        }
    }

    private Node first;
    private Node last;

    public Queue() {
        this.first = null;
        this.last = null;
    }

    public void enqueue(String entry){
        Node newNode = new Node();
        newNode.data = entry;

        if (isEmpty())
            this.first = newNode;
        else
            this.last.next = newNode;
        this.last = newNode;
    }

    public String dequeue(){
        String toRemove = getFront();
        this.first = this.first.next;
        if (this.first == null)
            this.last = null;
        return toRemove;

    }

    public String getFront(){
        if (isEmpty()){
            throw new IllegalArgumentException("Queue is empty");
        }
        return this.first.data;
    }

    public boolean isEmpty(){
        return this.first == null;
    }

    public void clear(){
        this.first = null;
        this.last = null;
    }
}
