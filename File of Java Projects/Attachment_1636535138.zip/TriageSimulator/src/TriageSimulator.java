public class TriageSimulator {
    private Queue queuePriority1, queuePriority2, queuePriority3;

    public TriageSimulator() {
        this.queuePriority1 = new Queue();
        this.queuePriority2 = new Queue();
        this.queuePriority3 = new Queue();
    }

    public void add(String data){
        String[] line = data.split(" ");
        int priority = getPriorityNumber(line[2]);
        String name = line[0] + " " +line[1];

        if (priority == 1)
            queuePriority1.enqueue(name);
        else if (priority == 2)
            queuePriority2.enqueue(name);
        else
            queuePriority3.enqueue(name);
    }

    public String remove(){
        if (!queuePriority1.isEmpty())
            return queuePriority1.dequeue();
        else if (!queuePriority2.isEmpty())
            return queuePriority2.dequeue();
        return queuePriority3.dequeue();
    }

    public boolean isEmpty(){
        return queuePriority1.isEmpty() && queuePriority2.isEmpty() && queuePriority3.isEmpty();
    }

    public int getPriorityNumber(String code){
        if (code.equals("AL") || code.equals("HA") || code.equals("ST"))
            return 1;
        else if (code.equals("BL") || code.equals("SF") || code.equals("IW") ||
                code.equals("KS") || code.equals("OT"))
            return 2;
        return 3;
    }
}
