import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        TriageSimulator simulator = new TriageSimulator();

        try {
            FileReader reader = new FileReader("data.txt");
            Scanner scan = new Scanner(reader);

            while (scan.hasNext()){
                simulator.add(scan.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("Next person who will be seen by doctor: " + simulator.remove());
        System.out.println("Next person who will be seen by doctor: " + simulator.remove());
        System.out.println("Next person who will be seen by doctor: " + simulator.remove());
        System.out.println("Next person who will be seen by doctor: " + simulator.remove());
        System.out.println("Next person who will be seen by doctor: " + simulator.remove());
        System.out.println("Next person who will be seen by doctor: " + simulator.remove());
        System.out.println("Next person who will be seen by doctor: " + simulator.remove());
        System.out.println("Next person who will be seen by doctor: " + simulator.remove());

    }
}
