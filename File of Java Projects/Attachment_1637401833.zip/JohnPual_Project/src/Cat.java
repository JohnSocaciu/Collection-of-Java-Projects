import java.util.function.Consumer;

public class Cat extends Animal   
{
   public Cat(String name) 
   {
      super(name);
   }

   public void speak()
   {
      System.out.println("says 'Meow'");
   } 
}
